<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Buku;

class ControllerBuku extends Controller
{
    public function create(Request $request)
    {
        $data = $request->all();
        $buku = Buku::create($data);

        return response()->json($buku);
    }
} 