<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Buku;

class ControllerBuku extends Controller
{
    public function create(Request $request)
    {
        $data = $request->all();
        $buku = Buku::create($data);

        return response()->json($buku);
    }

    public function index()
    {
        $buku = Buku::all();
        return response()->json($buku);
    }

    public function show($id)
    {
        $buku = Buku::find($id);
        return response()->json($buku);
    }

    public function update(Request $request, $id)
    {
  
        $buku = Buku::whereId($id)->update([
            'namabuku'      => $request->input('namabuku'),
            'harga'         => $request->input('harga'),
            'deskripsi'     => $request->input('deskripsi'),
        ]);

        if ($buku) {
            return response()->json([
                'success' => true,
                'message' => 'Data Berhasil Diupdate!',
                'data' => $buku
            ], 201);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Data Gagal Diupdate!',
            ], 400);
        }

    }

    public function delete($id)
    {
        $buku = Buku::whereId($id)->first();
        $buku->delete();

        if($buku){
            return response()->json([
                'success' => true,
                'message' => 'Data Berhasil Dihapus'
            ],200);
        }
    }
}

